var a01943 =
[
    [ "dvalue", "df/dd8/a01943.html#ac5c5ea767b03cb118efd0c477bddbd82", null ],
    [ "fvalue", "df/dd8/a01943.html#ad65d754ea405734e11612e0248761f15", null ],
    [ "ivalue", "df/dd8/a01943.html#a8ddc79eb2d7ba879158972453d9eeb90", null ],
    [ "name", "df/dd8/a01943.html#a33e03d46be7149547014d38f46547a0b", null ],
    [ "svalue", "df/dd8/a01943.html#a7ea3f6f56be4fbae658400d085d5da7e", null ],
    [ "type", "df/dd8/a01943.html#a01277f2b005ca7dd60ae5652d9f06756", null ]
];