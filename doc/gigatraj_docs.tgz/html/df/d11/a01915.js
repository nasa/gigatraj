var a01915 =
[
    [ "HGridSpec", "df/d11/a01915.html#aa4c0683907a68b50dcfe3d0cd3fdbc4e", null ],
    [ "~HGridSpec", "df/d11/a01915.html#a002b2dc2739866adb349eac98ab962d5", null ],
    [ "clear", "df/d11/a01915.html#a885007c0a2a9586b25e16410699517a4", null ],
    [ "set", "df/d11/a01915_ad4bb5f6dc4765f6f3a736eafb766c16c.html#ad4bb5f6dc4765f6f3a736eafb766c16c", null ],
    [ "test", "df/d11/a01915_a5f68585ab652049f9d9593f929b7ab24.html#a5f68585ab652049f9d9593f929b7ab24", null ],
    [ "code", "df/d11/a01915.html#aba9e5053b14176e56b43ec35f4f0b519", null ],
    [ "deltaLat", "df/d11/a01915.html#a7276781565b619286cb3ec37294608e0", null ],
    [ "deltaLon", "df/d11/a01915.html#a7f85b72f680fbd9952c97333f55f9064", null ],
    [ "endLat", "df/d11/a01915.html#a9c94eb9319bbeebd745fb79ceac857e3", null ],
    [ "endLon", "df/d11/a01915.html#a2eafefb12d690fa9cddfc145669f0bc3", null ],
    [ "given", "df/d11/a01915_aa11af8e5e17cb9940c1ee1091a492953.html#aa11af8e5e17cb9940c1ee1091a492953", null ],
    [ "nLats", "df/d11/a01915.html#a7b17fdc4d2b575e487cf5179151843f0", null ],
    [ "nLons", "df/d11/a01915.html#a40d8c9c97b014282c7c19cb64eaab6e1", null ],
    [ "startLat", "df/d11/a01915.html#ac17918dbcb1eb702ec42bcbc2c0f4072", null ],
    [ "startLon", "df/d11/a01915.html#a174fdbc7434535d77b9685b1a74beeda", null ],
    [ "thin", "df/d11/a01915.html#a21bff1ce4899af89d3a06bd6a45b18e5", null ],
    [ "thin_offset", "df/d11/a01915.html#a26ca1506b859c4d0565ca5d5747078f1", null ]
];