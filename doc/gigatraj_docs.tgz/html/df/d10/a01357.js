var a01357 =
[
    [ "clear", "df/d10/a01357_a3320d7015541071ed4e6215b184f2cb0.html#a3320d7015541071ed4e6215b184f2cb0", null ],
    [ "define", "df/d10/a01357_a91147ce553c6c3d18fd2869ee3fbf5c3.html#a91147ce553c6c3d18fd2869ee3fbf5c3", null ],
    [ "dump", "df/d10/a01357_af44aa59434705dafb4e65f57782908d7.html#af44aa59434705dafb4e65f57782908d7", null ],
    [ "exists", "df/d10/a01357_a29ba542e81e90d69eff68bf0cc22763e.html#a29ba542e81e90d69eff68bf0cc22763e", null ],
    [ "getDimension", "df/d10/a01357_a81f2a54ebb899ecf838585320e00c14c.html#a81f2a54ebb899ecf838585320e00c14c", null ]
];