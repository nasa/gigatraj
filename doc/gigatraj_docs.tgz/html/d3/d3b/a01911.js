var a01911 =
[
    [ "badNetcdfError", "d3/d3b/a01911.html#a4289f26db8dcc77005f62e3296d72d16", null ],
    [ "error", "d3/d3b/a01911.html#a35d55ae0803dbc9a08d5dd070c074233", null ]
];