var a01995 =
[
    [ "MPVOTF", "d3/dd8/a01995_a924fd23b1b63f7744ac3d2835fcb2e16.html#a924fd23b1b63f7744ac3d2835fcb2e16", null ],
    [ "MPVOTF", "d3/dd8/a01995_a32d2042f38dedbaa5804a38d58e144ce.html#a32d2042f38dedbaa5804a38d58e144ce", null ],
    [ "~MPVOTF", "d3/dd8/a01995_aa5a7cc35ab87a5499cde99bc80e87220.html#aa5a7cc35ab87a5499cde99bc80e87220", null ],
    [ "calc", "d3/dd8/a01995_a1cf901bcbcbba9d8b059eb5ef1859370.html#a1cf901bcbcbba9d8b059eb5ef1859370", null ],
    [ "calc", "d3/dd8/a01995_ab7c756ede6f2155a1d507286c5e7b8a5.html#ab7c756ede6f2155a1d507286c5e7b8a5", null ],
    [ "calc", "d3/dd8/a01995_a2c0533772ef4cf84d7368f6b710d7f9b.html#a2c0533772ef4cf84d7368f6b710d7f9b", null ],
    [ "quantity", "d3/dd8/a01995.html#a89926ff3ab8c1fcd885000d658579979", null ],
    [ "set_quantity", "d3/dd8/a01995.html#a72d78ec391aa14b218efd2a3dabdb4e3", null ],
    [ "set_units", "d3/dd8/a01995.html#af04fcb8616fd992b555e29a78fd753d6", null ],
    [ "setEPVName", "d3/dd8/a01995_accd7b594ce9830a9ff93c4289a32ec98.html#accd7b594ce9830a9ff93c4289a32ec98", null ],
    [ "setPotentialTemperatureName", "d3/dd8/a01995_a22e1500c77c02e4bbf6132a6f554074e.html#a22e1500c77c02e4bbf6132a6f554074e", null ],
    [ "units", "d3/dd8/a01995.html#a1389bfd07a90c563b0b1c8fbd78d44f0", null ],
    [ "ename", "d3/dd8/a01995.html#ab0793c1f396c042b6dcb1ec651ebf08f", null ],
    [ "hname", "d3/dd8/a01995.html#aee33d4265bdaf0253eb22e2a5e6fe465", null ],
    [ "quant", "d3/dd8/a01995.html#aa552b7e918269e63e16e1b12ab02ba8f", null ],
    [ "uu", "d3/dd8/a01995.html#a41c9ad58c280139449699975dffe19e1", null ]
];