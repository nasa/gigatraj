var namespaces_dup =
[
    [ "gigatraj", "d8/d67/a00499.html", "d8/d67/a00499" ]
];