var namespaces_dup =
[
    [ "gigatraj", "d9/da5/a00493.html", "d9/da5/a00493" ]
];