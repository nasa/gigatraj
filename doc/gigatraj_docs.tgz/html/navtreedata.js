/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "gigatraj", "index.html", [
    [ "The gigatraj Trajectory Model", "index.html", [
      [ "Introduction", "index.html#sec_intro", null ],
      [ "Overview", "index.html#sec_overview", null ],
      [ "Parallel Processing", "index.html#sec_parallel", null ],
      [ "Installation", "index.html#installation", null ],
      [ "pages of interest", "index.html#Other", null ]
    ] ],
    [ "Standalone programs that use the gigatraj toolkit.", "db/d7f/a03150.html", "db/d7f/a03150" ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"d1/dc5/a02013_ae0bb4197c7c670f182f80f2f7694e588.html#ae0bb4197c7c670f182f80f2f7694e588",
"d2/d5b/a01841.html#a9a529152bc1807e11f500731b53b4a90",
"d3/d21/a01657_a114a26918c48a152e3274303e17a7094.html#a114a26918c48a152e3274303e17a7094",
"d3/dac/a01777.html#a2b2014865c166f49cd62dd86a93ca307",
"d3/dac/a01777.html#af9f01a00bab87feb4ed4f5e1a6b8f152",
"d4/dad/a01353_ac411fb6979ce276629fd9aa48414590a.html#ac411fb6979ce276629fd9aa48414590a",
"d5/d36/a01773.html#aad3b9c14bded3d40380550c853e6ef6c",
"d6/d27/a01781.html#a267438c7ae380b06b60f5d52fb9af497",
"d6/d27/a01781.html#af67d7cd80755f4c314f13793ab92f520",
"d7/d10/a01785_a50343e83c3cf6ec2692894622b1bf1d6.html#a50343e83c3cf6ec2692894622b1bf1d6",
"d7/d53/a01645_a14c9f41102861cdeb3dee167863db983.html#a14c9f41102861cdeb3dee167863db983",
"d9/d6f/a01445_a85b3db9a9cbfc3481b7c4e233501d885.html#a85b3db9a9cbfc3481b7c4e233501d885",
"da/d20/a01689.html#ac7572bda907a3ae3bbfb7df40bb99f48",
"da/d8c/a01845.html#a607e5f5d9db730ad723e970822197be2",
"db/d6b/a01853.html#a0c602c5390899ddd29eeca4c291b5f46",
"db/d6b/a01853_a7ab6584530c7f46bced9e5b7e9c9542c.html#a7ab6584530c7f46bced9e5b7e9c9542c",
"db/dd4/a01849.html#a54e306cd3eb499189116d5a3b295f7dd",
"db/dd5/a01833.html#a5213b757225579fe5a080314e4a7a948",
"dc/da7/a01933.html#a33e03d46be7149547014d38f46547a0b",
"de/d90/a01313_a8eebbd2d85df857547856526ac425a65.html#a8eebbd2d85df857547856526ac425a65",
"df/d29/a01329_ab3458f3695ab4305cc5620e83932f5cf.html#ab3458f3695ab4305cc5620e83932f5cf",
"functions_vars_c.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';