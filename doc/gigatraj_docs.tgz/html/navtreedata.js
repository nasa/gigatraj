/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "gigatraj", "index.html", [
    [ "The gigatraj Trajectory Model", "index.html", [
      [ "Introduction", "index.html#sec_intro", null ],
      [ "Overview", "index.html#sec_overview", null ],
      [ "Parallel Processing", "index.html#sec_parallel", null ],
      [ "Installation", "index.html#installation", null ],
      [ "pages of interest", "index.html#Other", null ]
    ] ],
    [ "Standalone programs that use the gigatraj toolkit.", "d8/d08/a03160.html", "d8/d08/a03160" ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"d1/de9/a01855.html#a3e4efc5be269b47d701d14b7e2161341",
"d1/dea/a01791.html#a079fdcc338d3c50fd8679ca72163c0de",
"d1/dea/a01791.html#ad68611880d833478da29f01bc52a5aee",
"d2/d36/a01495.html#aa1bf196b97f4e03660902020cc066fb6",
"d2/dca/a01683.html#aabe6b72337998b0e52818b3b9c00c36c",
"d3/dce/a01859.html#a1dd0cf52eff558372ea8f191cc5329b9",
"d3/dce/a01859.html#ae4b7636397c93fd432d7205bf34ac458",
"d4/d12/a01863.html#ad1b4ab54583a2e6ff71f4e6f2384b20a",
"d4/d3c/a01671.html#a2bd26143789e7bb0249222dc24b127ac",
"d5/d1b/a01971.html#a6132155f593e7465adc1f8f1e1b87ade",
"d5/dd6/a02055_a0ce5d2df71dbdd8408e3e4c720afa27b.html#a0ce5d2df71dbdd8408e3e4c720afa27b",
"d6/dd2/a02243_ac8942cf30762148c027233c8e9da4aa7.html#ac8942cf30762148c027233c8e9da4aa7",
"d8/df7/a01711_a47480547a56b4d6557141176d9bf400c.html#a47480547a56b4d6557141176d9bf400c",
"d9/de1/a01923.html#a7708489b4c660aa91eab2e71398f28b3",
"da/da5/a01783.html#a4e7a6b2b1a2c4561b896fa61caebfa0f",
"da/ded/a01547_a9c75dbc8ce4c4dbe061212b5fcb15687.html#a9c75dbc8ce4c4dbe061212b5fcb15687",
"dc/d93/a01535.html#adac33a0452809efef15b77d3366b4ca2",
"dd/d2d/a01635.html#a25e9541b1210f875037dd9743fae751c",
"dd/d8d/a01667.html#a90ccea2290169baae06dcd899535d7c0",
"de/dc3/a01787.html#a34d0b146a47505ccbc86ba1218323b05",
"de/dc3/a01787_acc440c6e550d73d5791151914d5e0733.html#acc440c6e550d73d5791151914d5e0733",
"functions_e.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';