/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "gigatraj", "index.html", [
    [ "The gigatraj Trajectory Model", "index.html", [
      [ "Introduction", "index.html#sec_intro", null ],
      [ "Overview", "index.html#sec_overview", null ],
      [ "Parallel Processing", "index.html#sec_parallel", null ],
      [ "Installation", "index.html#installation", null ],
      [ "pages of interest", "index.html#Other", null ]
    ] ],
    [ "Standalone programs that use the gigatraj toolkit.", "d8/d08/a03160.html", "d8/d08/a03160" ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"d1/de9/a01855.html#a3f73c9de51859ef0e98795f20ff2fc1a",
"d1/dea/a01791.html#a08b33fa15c8e6462df1dece134c68f6b",
"d1/dea/a01791.html#ad7c38f9100da95f9be12a45a6275c787",
"d2/d36/a01495.html#aa2964b20527b53e75a3d9f84eb1c296f",
"d2/dca/a01683.html#ab5130616692bfd05a301c9f4b37e7159",
"d3/dce/a01859.html#a1e4f136f376b4cb727c89e7fde1a05d0",
"d3/dce/a01859.html#ae544ff7b88b8d56e69a645be3cc4b5a0",
"d4/d12/a01863.html#ad348389efb4e8de3b482883b1e727054",
"d4/d3c/a01671.html#a25e9541b1210f875037dd9743fae751c",
"d5/d1b/a01971.html#a5dba0783cc15f6df95382d69ff7f4e32",
"d5/dd6/a02055_a0c16d5b18a29f7dfb9afbeb96bbcded2.html#a0c16d5b18a29f7dfb9afbeb96bbcded2",
"d6/dd2/a02243_ac70ef8d5f20e09984326320bf10a5695.html#ac70ef8d5f20e09984326320bf10a5695",
"d8/df7/a01711_a26492af5ae5770ef5908b3e261cffeec.html#a26492af5ae5770ef5908b3e261cffeec",
"d9/de1/a01923.html#a1974cad24ce0ed92455db73c89a54f37",
"da/da5/a01783.html#a4bf68df19b8d25de671adb4fe0f8c671",
"da/ded/a01547_a6f33fca9104cd4e2bbf46f5ddd895948.html#a6f33fca9104cd4e2bbf46f5ddd895948",
"dc/d93/a01535.html#a3ac083556d7d642e31f4e6768b9c97a1",
"dd/d2d/a01635.html#a1dad15cf8ad612180ff27a5590d8db47",
"dd/d8d/a01667.html#a73109b17fc6420bdf084d9df98477ac7",
"de/dc3/a01787.html#a31a5de88354c0a0e27f1ad070a9094b2",
"de/dc3/a01787_a141cee541adb2ca088e466d12350d75c.html#a141cee541adb2ca088e466d12350d75c",
"functions.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';