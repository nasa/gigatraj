var a01901 =
[
    [ "badNetcdfError", "d5/d99/a01901.html#a4289f26db8dcc77005f62e3296d72d16", null ],
    [ "error", "d5/d99/a01901.html#a35d55ae0803dbc9a08d5dd070c074233", null ]
];