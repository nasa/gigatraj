var a01499 =
[
    [ "badLockExists", "d6/df5/a01503.html", null ],
    [ "badLockFailed", "d8/dd9/a01507.html", null ],
    [ "badLockFailed_A", "da/d50/a01511.html", null ],
    [ "badLockFailed_B", "d2/de0/a01515.html", null ],
    [ "badLockIOErr", "d4/d62/a01531.html", null ],
    [ "badLockRmFailed", "d1/d34/a01519.html", null ],
    [ "badNotReadable", "d8/d8c/a01527.html", null ],
    [ "badNotWriteable", "db/d8e/a01523.html", null ],
    [ "FileLock", "d5/d06/a01499_ac9f0b960ae29a4d42255faf813a98a80.html#ac9f0b960ae29a4d42255faf813a98a80", null ],
    [ "FileLock", "d5/d06/a01499_a0d2610ef510e900317de0ca01c0ebf45.html#a0d2610ef510e900317de0ca01c0ebf45", null ],
    [ "~FileLock", "d5/d06/a01499_a25451a8741b31e206ea3eb8aa515b5ea.html#a25451a8741b31e206ea3eb8aa515b5ea", null ],
    [ "closer", "d5/d06/a01499_ae43403cf06a521748cd0ef90a8aec483.html#ae43403cf06a521748cd0ef90a8aec483", null ],
    [ "closer", "d5/d06/a01499_a52ff9d73fcc27d21506df3ffb97ac782.html#a52ff9d73fcc27d21506df3ffb97ac782", null ],
    [ "init", "d5/d06/a01499_ad66fea30450b2b34e1c91394f51a9bb8.html#ad66fea30450b2b34e1c91394f51a9bb8", null ],
    [ "openr", "d5/d06/a01499_af42a8e639da108e7a3ab7abd54c3455e.html#af42a8e639da108e7a3ab7abd54c3455e", null ],
    [ "openw", "d5/d06/a01499_a3e9235ab9d58621fed8c4f2dfa211082.html#a3e9235ab9d58621fed8c4f2dfa211082", null ],
    [ "debug", "d5/d06/a01499.html#a31f5cce22880ab1028ca3157e691ed32", null ],
    [ "id", "d5/d06/a01499.html#ac0c9527fd8c14f937cf60172a2c3ed65", null ]
];