var a01933 =
[
    [ "dvalue", "dc/da7/a01933.html#ac5c5ea767b03cb118efd0c477bddbd82", null ],
    [ "fvalue", "dc/da7/a01933.html#ad65d754ea405734e11612e0248761f15", null ],
    [ "ivalue", "dc/da7/a01933.html#a8ddc79eb2d7ba879158972453d9eeb90", null ],
    [ "name", "dc/da7/a01933.html#a33e03d46be7149547014d38f46547a0b", null ],
    [ "svalue", "dc/da7/a01933.html#a7ea3f6f56be4fbae658400d085d5da7e", null ],
    [ "type", "dc/da7/a01933.html#a01277f2b005ca7dd60ae5652d9f06756", null ]
];