var a01897 =
[
    [ "badNetcdfOpen", "d9/d0c/a01897.html#a9831bcfe1cf7a6595673955ed111ecc8", null ],
    [ "error", "d9/d0c/a01897.html#af5a2ce076c3b04decd7739f1b4ec447b", null ]
];