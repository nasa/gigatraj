var a00478 =
[
    [ "Meteorological Miscellaneous", "d7/d5e/a00467.html", "d7/d5e/a00467" ],
    [ "Gridded Field Data", "d7/db5/a00472.html", "d7/db5/a00472" ],
    [ "Meteorological Data Sources", "d9/d4a/a00479.html", "d9/d4a/a00479" ],
    [ "On-The-Fly (OTF) Calculators", "d9/dc5/a00480.html", "d9/dc5/a00480" ]
];