var a01937 =
[
    [ "badcalculation", "da/d76/a01941.html", null ],
    [ "badgrid", "dd/d2e/a01949.html", null ],
    [ "badinputquant", "d9/d97/a01953.html", null ],
    [ "badinputunits", "d2/d6f/a01957.html", null ],
    [ "badprofile", "d5/d39/a01945.html", null ],
    [ "quantity", "d9/d17/a01937.html#a89926ff3ab8c1fcd885000d658579979", null ],
    [ "set_quantity", "d9/d17/a01937_a72d78ec391aa14b218efd2a3dabdb4e3.html#a72d78ec391aa14b218efd2a3dabdb4e3", null ],
    [ "set_units", "d9/d17/a01937_af04fcb8616fd992b555e29a78fd753d6.html#af04fcb8616fd992b555e29a78fd753d6", null ],
    [ "units", "d9/d17/a01937.html#a1389bfd07a90c563b0b1c8fbd78d44f0", null ],
    [ "quant", "d9/d17/a01937.html#aa552b7e918269e63e16e1b12ab02ba8f", null ],
    [ "uu", "d9/d17/a01937.html#a41c9ad58c280139449699975dffe19e1", null ]
];