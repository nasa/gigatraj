var a00490 =
[
    [ "HitBad", "d7/daa/a00490.html#ga1dfc3797bd66db0ec1f952f23ca26632", null ],
    [ "HitBdy", "d7/daa/a00490.html#gade68fc11db400be108f1c9f3dfa4fbc5", null ],
    [ "Inert", "d7/daa/a00490.html#ga6af05086a9e533b303ca53f98290aa6b", null ],
    [ "NonVert", "d7/daa/a00490.html#ga87f77efc4cbbee688cf5bb96cfc57dc1", null ]
];