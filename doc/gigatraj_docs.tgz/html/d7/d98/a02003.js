var a02003 =
[
    [ "badNetcdfOpen", "d7/d98/a02003.html#abb7bb51b8cb2d905c23b82c185f02c26", null ],
    [ "error", "d7/d98/a02003.html#aa0977538f034c6876e5abb977988097f", null ]
];