var a01997 =
[
    [ "badNetcdfError", "d0/d2b/a01997.html#a40b628f2e8474cb445a7da8cfb90a696", null ],
    [ "error", "d0/d2b/a01997.html#a276eeaf3eb189371c30533d6e2def659", null ]
];