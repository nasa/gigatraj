var a01379 =
[
    [ "TargetRef", "d0/d9b/a01379.html#ac5f276378476b61813ff8968568b324f", null ],
    [ "TargetRef", "d0/d9b/a01379_a02c53a36cd959f7dd3728d7b21d00b48.html#a02c53a36cd959f7dd3728d7b21d00b48", null ],
    [ "dump", "d0/d9b/a01379_afc69119bb2b9506fea5994df2be837c5.html#afc69119bb2b9506fea5994df2be837c5", null ],
    [ "description", "d0/d9b/a01379.html#a3f2880ae861f54da42fb37f387fc4025", null ],
    [ "offset", "d0/d9b/a01379.html#aebb50ab7a112153a58496828c5ef0b12", null ],
    [ "scale", "d0/d9b/a01379.html#a53ee782a546fe914452c5cab9d165f84", null ],
    [ "tname", "d0/d9b/a01379.html#a28dd88153f75726f808a6b34eb53aa36", null ],
    [ "units", "d0/d9b/a01379.html#a674abaae105a45b6177599ee40bec02a", null ]
];