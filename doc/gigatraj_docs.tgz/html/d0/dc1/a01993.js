var a01993 =
[
    [ "badNetcdfOpen", "d0/dc1/a01993.html#abb7bb51b8cb2d905c23b82c185f02c26", null ],
    [ "error", "d0/dc1/a01993.html#aa0977538f034c6876e5abb977988097f", null ]
];