var a01485 =
[
    [ "DensOTF", "d4/d39/a01485_a55c8fb6d50de6a87fd90e5abda546bc4.html#a55c8fb6d50de6a87fd90e5abda546bc4", null ],
    [ "DensOTF", "d4/d39/a01485_a7afb1ea188e660df45a029acb53d9228.html#a7afb1ea188e660df45a029acb53d9228", null ],
    [ "~DensOTF", "d4/d39/a01485_a09633aa8cfdd8ba51a08e442f374f2af.html#a09633aa8cfdd8ba51a08e442f374f2af", null ],
    [ "calc", "d4/d39/a01485.html#a7224df5e2b499347b8603bf309912f11", null ],
    [ "calc", "d4/d39/a01485_ab87cef6333c81f7da1d4da41024e5d16.html#ab87cef6333c81f7da1d4da41024e5d16", null ],
    [ "calc", "d4/d39/a01485.html#a0ca692bc61887ca5a2b4034170ad9539", null ],
    [ "quantity", "d4/d39/a01485.html#a89926ff3ab8c1fcd885000d658579979", null ],
    [ "set_quantity", "d4/d39/a01485.html#a72d78ec391aa14b218efd2a3dabdb4e3", null ],
    [ "set_units", "d4/d39/a01485.html#af04fcb8616fd992b555e29a78fd753d6", null ],
    [ "setPotentialTemperatureName", "d4/d39/a01485_ac9acf2339ff29746d86f6a34180fda2c.html#ac9acf2339ff29746d86f6a34180fda2c", null ],
    [ "setPressureName", "d4/d39/a01485_a1bd35a829bb79e6d5ee423cdad84ae8f.html#a1bd35a829bb79e6d5ee423cdad84ae8f", null ],
    [ "setTemperatureName", "d4/d39/a01485_a58008cbc5eb3000523b8b6472bcb8185.html#a58008cbc5eb3000523b8b6472bcb8185", null ],
    [ "units", "d4/d39/a01485.html#a1389bfd07a90c563b0b1c8fbd78d44f0", null ],
    [ "dens_name", "d4/d39/a01485.html#a8fe798b550ae051cd7b0b3201e931984", null ],
    [ "press_name", "d4/d39/a01485.html#a2eeb25da0c5f2bf473d5bd92ef162646", null ],
    [ "quant", "d4/d39/a01485.html#aa552b7e918269e63e16e1b12ab02ba8f", null ],
    [ "temp_name", "d4/d39/a01485.html#a35c860fa7dfbb66393694efced898305", null ],
    [ "theta_name", "d4/d39/a01485.html#a47eb635cfc7c5c0ce74621ab07f5ff65", null ],
    [ "uu", "d4/d39/a01485.html#a41c9ad58c280139449699975dffe19e1", null ]
];