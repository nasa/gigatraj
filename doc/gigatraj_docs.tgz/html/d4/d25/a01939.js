var a01939 =
[
    [ "delta", "d4/d25/a01939.html#a44380f10df9ce197ebb689adad864ed5", null ],
    [ "first", "d4/d25/a01939.html#a9e284279755b050fe4dc8106a1a50c78", null ],
    [ "last", "d4/d25/a01939.html#af80529a8ec84411ed424e01b2833f067", null ],
    [ "size", "d4/d25/a01939.html#aea76ffff2a87eb9aee28bb0ab1756e03", null ]
];