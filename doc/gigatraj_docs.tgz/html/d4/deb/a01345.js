var a01345 =
[
    [ "Variable", "d4/deb/a01345_a0f645d057e566bd8f4ec87ef378468e5.html#a0f645d057e566bd8f4ec87ef378468e5", null ],
    [ "~Variable", "d4/deb/a01345_a63bb1efe7e728064fe792797986f8c70.html#a63bb1efe7e728064fe792797986f8c70", null ],
    [ "addValue", "d4/deb/a01345_a52fcab797ea1120b7c631c58978fdbd8.html#a52fcab797ea1120b7c631c58978fdbd8", null ],
    [ "dump", "d4/deb/a01345_ae0061a2b69688123d7743ee75dcdb9a4.html#ae0061a2b69688123d7743ee75dcdb9a4", null ],
    [ "getExprs", "d4/deb/a01345_a564fc347aba2be8386e26b1d8b1d86d2.html#a564fc347aba2be8386e26b1d8b1d86d2", null ],
    [ "size", "d4/deb/a01345_a216787e30415a78f25755e167e55d1ab.html#a216787e30415a78f25755e167e55d1ab", null ],
    [ "defined", "d4/deb/a01345.html#a670e1bc62dc6f1eb5d0fb4a7f6e1f399", null ],
    [ "name", "d4/deb/a01345.html#ab518ef8dbaece84efffe1a1b1d943f55", null ],
    [ "type", "d4/deb/a01345.html#a56ce143c83c9f7eb0b6c55abd6ead19c", null ]
];