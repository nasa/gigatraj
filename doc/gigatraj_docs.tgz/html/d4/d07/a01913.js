var a01913 =
[
    [ "TGridSpec", "d4/d07/a01913.html#a7708489b4c660aa91eab2e71398f28b3", null ],
    [ "~TGridSpec", "d4/d07/a01913.html#aee5e32bfd8ea867e3d3a4f4f8a753b4a", null ],
    [ "clear", "d4/d07/a01913.html#ab7d54b824395b15cc7f8857bb7a16d7d", null ],
    [ "get", "d4/d07/a01913_a44bdb44696f02387c6e0e6594b732257.html#a44bdb44696f02387c6e0e6594b732257", null ],
    [ "inside", "d4/d07/a01913_a9272aa26373250a7fc2553bc87a74bf4.html#a9272aa26373250a7fc2553bc87a74bf4", null ],
    [ "merge", "d4/d07/a01913_a9bc8125a430d6b7a422c5ff2970819bb.html#a9bc8125a430d6b7a422c5ff2970819bb", null ],
    [ "set", "d4/d07/a01913_a03e7eaf25fa78e42523ef1c5bf87996b.html#a03e7eaf25fa78e42523ef1c5bf87996b", null ],
    [ "set", "d4/d07/a01913_aa63f74b71596a3e7c350cbe9a2d80ece.html#aa63f74b71596a3e7c350cbe9a2d80ece", null ],
    [ "set", "d4/d07/a01913_af151e5d97934830ac5fd047c99a04783.html#af151e5d97934830ac5fd047c99a04783", null ],
    [ "test", "d4/d07/a01913_a67cc8ea382c6f257be23029f9682f498.html#a67cc8ea382c6f257be23029f9682f498", null ],
    [ "delta", "d4/d07/a01913.html#a625484620572c4a5dcf77d6e3582f3dd", null ],
    [ "end", "d4/d07/a01913.html#ac592f1c8f56599143fed60bfcbf7c45c", null ],
    [ "given", "d4/d07/a01913_a6ca57810f43134dba6679ebb94989a25.html#a6ca57810f43134dba6679ebb94989a25", null ],
    [ "n", "d4/d07/a01913.html#a011b2c27e0a53b9d9721f51276a57b2b", null ],
    [ "next", "d4/d07/a01913.html#aec7f597e39a5e2cd448d4cf4183c1370", null ],
    [ "start", "d4/d07/a01913.html#ada7b77c5dc45b9dccce1e05af08b1413", null ],
    [ "tave", "d4/d07/a01913.html#ad301a25501db9dd5cec78f1ffe823989", null ],
    [ "toff", "d4/d07/a01913.html#a1974cad24ce0ed92455db73c89a54f37", null ]
];