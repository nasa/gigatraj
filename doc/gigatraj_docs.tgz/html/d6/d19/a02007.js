var a02007 =
[
    [ "badNetcdfError", "d6/d19/a02007.html#a40b628f2e8474cb445a7da8cfb90a696", null ],
    [ "error", "d6/d19/a02007.html#a276eeaf3eb189371c30533d6e2def659", null ]
];