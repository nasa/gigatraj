var a01947 =
[
    [ "badcalculation", "d8/ddf/a01951.html", null ],
    [ "badgrid", "dc/da8/a01959.html", null ],
    [ "badinputquant", "d3/dce/a01963.html", null ],
    [ "badinputunits", "de/d46/a01967.html", null ],
    [ "badprofile", "d4/d93/a01955.html", null ],
    [ "quantity", "d6/d19/a01947.html#a89926ff3ab8c1fcd885000d658579979", null ],
    [ "set_quantity", "d6/d19/a01947_a72d78ec391aa14b218efd2a3dabdb4e3.html#a72d78ec391aa14b218efd2a3dabdb4e3", null ],
    [ "set_units", "d6/d19/a01947_af04fcb8616fd992b555e29a78fd753d6.html#af04fcb8616fd992b555e29a78fd753d6", null ],
    [ "units", "d6/d19/a01947.html#a1389bfd07a90c563b0b1c8fbd78d44f0", null ],
    [ "quant", "d6/d19/a01947.html#aa552b7e918269e63e16e1b12ab02ba8f", null ],
    [ "uu", "d6/d19/a01947.html#a41c9ad58c280139449699975dffe19e1", null ]
];