var a01493 =
[
    [ "badLockExists", "db/d1e/a01497.html", null ],
    [ "badLockFailed", "db/d2c/a01501.html", null ],
    [ "badLockFailed_A", "dc/dce/a01505.html", null ],
    [ "badLockFailed_B", "db/d06/a01509.html", null ],
    [ "badLockIOErr", "db/de9/a01525.html", null ],
    [ "badLockRmFailed", "d0/d62/a01513.html", null ],
    [ "badNotReadable", "dc/d42/a01521.html", null ],
    [ "badNotWriteable", "dc/d96/a01517.html", null ],
    [ "FileLock", "d2/d41/a01493_ac9f0b960ae29a4d42255faf813a98a80.html#ac9f0b960ae29a4d42255faf813a98a80", null ],
    [ "FileLock", "d2/d41/a01493_a0d2610ef510e900317de0ca01c0ebf45.html#a0d2610ef510e900317de0ca01c0ebf45", null ],
    [ "~FileLock", "d2/d41/a01493_a25451a8741b31e206ea3eb8aa515b5ea.html#a25451a8741b31e206ea3eb8aa515b5ea", null ],
    [ "closer", "d2/d41/a01493_ae43403cf06a521748cd0ef90a8aec483.html#ae43403cf06a521748cd0ef90a8aec483", null ],
    [ "closer", "d2/d41/a01493_a52ff9d73fcc27d21506df3ffb97ac782.html#a52ff9d73fcc27d21506df3ffb97ac782", null ],
    [ "init", "d2/d41/a01493_ad66fea30450b2b34e1c91394f51a9bb8.html#ad66fea30450b2b34e1c91394f51a9bb8", null ],
    [ "openr", "d2/d41/a01493_af42a8e639da108e7a3ab7abd54c3455e.html#af42a8e639da108e7a3ab7abd54c3455e", null ],
    [ "openw", "d2/d41/a01493_a3e9235ab9d58621fed8c4f2dfa211082.html#a3e9235ab9d58621fed8c4f2dfa211082", null ],
    [ "debug", "d2/d41/a01493.html#a31f5cce22880ab1028ca3157e691ed32", null ],
    [ "id", "d2/d41/a01493.html#ac0c9527fd8c14f937cf60172a2c3ed65", null ]
];