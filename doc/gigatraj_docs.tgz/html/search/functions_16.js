var searchData=
[
  ['zindex_1994',['zindex',['../d3/d2d/a01625_a06bd94dd626f0b0cc85ce042aed1794d.html#a06bd94dd626f0b0cc85ce042aed1794d',1,'gigatraj::GridField3D::zindex()'],['../d4/d41/a01661_ab04b1de53613e5cf5bcab77ac4da452f.html#ab04b1de53613e5cf5bcab77ac4da452f',1,'gigatraj::GridFieldProfile::zindex()']]]
];
