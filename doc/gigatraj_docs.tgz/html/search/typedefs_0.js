var searchData=
[
  ['configflag_2409',['ConfigFlag',['../dc/ddf/a00469_ga27149cada3978775310f809dab8fda05.html#ga27149cada3978775310f809dab8fda05',1,'gigatraj']]],
  ['configtype_2410',['ConfigType',['../dc/ddf/a00469_ga6a5372a50b238811d4f7c17190c9cf19.html#ga6a5372a50b238811d4f7c17190c9cf19',1,'gigatraj']]]
];
