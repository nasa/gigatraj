var searchData=
[
  ['standalone_20programs_20that_20use_20the_20gigatraj_20toolkit_2e_2468',['Standalone programs that use the gigatraj toolkit.',['../d8/d08/a03160.html',1,'']]]
];
