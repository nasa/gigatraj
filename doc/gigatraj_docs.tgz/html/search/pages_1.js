var searchData=
[
  ['standalone_20programs_20that_20use_20the_20gigatraj_20toolkit_2e_2454',['Standalone programs that use the gigatraj toolkit.',['../db/d7f/a03150.html',1,'']]]
];
