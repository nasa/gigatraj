var searchData=
[
  ['varoperator_2420',['VarOperator',['../dd/d5d/a01325.html#aef4148b1939e43af7867c62b345ea048',1,'gigatraj::Catalog']]]
];
