var searchData=
[
  ['parcelflag_2414',['ParcelFlag',['../d9/da5/a00493_a67b1408183f4df49526cef7097096c73.html#a67b1408183f4df49526cef7097096c73',1,'gigatraj']]],
  ['parcelstatus_2415',['ParcelStatus',['../d9/da5/a00493_ad54c3263127fd00bec7dd836a3772c1d.html#ad54c3263127fd00bec7dd836a3772c1d',1,'gigatraj']]]
];
