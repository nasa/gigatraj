var searchData=
[
  ['parcelflag_2428',['ParcelFlag',['../d8/d67/a00499_a67b1408183f4df49526cef7097096c73.html#a67b1408183f4df49526cef7097096c73',1,'gigatraj']]],
  ['parcelstatus_2429',['ParcelStatus',['../d8/d67/a00499_ad54c3263127fd00bec7dd836a3772c1d.html#ad54c3263127fd00bec7dd836a3772c1d',1,'gigatraj']]]
];
