var searchData=
[
  ['spanattr_2417',['SpanAttr',['../db/d6b/a01853.html#a2279da68eef5e9568093ad788106cd02',1,'gigatraj::MetMyGEOS']]],
  ['spantriplet_2418',['SpanTriplet',['../db/d6b/a01853.html#a86ca91715d531bc7285cbb654bf38469',1,'gigatraj::MetMyGEOS']]]
];
