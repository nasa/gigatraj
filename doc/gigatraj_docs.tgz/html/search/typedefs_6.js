var searchData=
[
  ['spanattr_2431',['SpanAttr',['../d4/d12/a01863.html#a2279da68eef5e9568093ad788106cd02',1,'gigatraj::MetMyGEOS']]],
  ['spantriplet_2432',['SpanTriplet',['../d4/d12/a01863.html#a86ca91715d531bc7285cbb654bf38469',1,'gigatraj::MetMyGEOS']]]
];
