var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuvwxyz~",
  1: "bcdefghilmnpqrstv",
  2: "g",
  3: "abcdefghijlmnopqrstuvwz~",
  4: "abcdefghijlmnopqrstuvwxyz",
  5: "cfimprs",
  6: "pv",
  7: "fos",
  8: "cghimopstv",
  9: "gst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "related",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Friends",
  8: "Modules",
  9: "Pages"
};

