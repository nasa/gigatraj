var a01907 =
[
    [ "badNetcdfOpen", "de/dca/a01907.html#a9831bcfe1cf7a6595673955ed111ecc8", null ],
    [ "error", "de/dca/a01907.html#af5a2ce076c3b04decd7739f1b4ec447b", null ]
];