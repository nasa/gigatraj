var a01383 =
[
    [ "Quantity", "de/dfe/a01383_a321345dffbe1772157b15fd96913cdc1.html#a321345dffbe1772157b15fd96913cdc1", null ],
    [ "clear", "de/dfe/a01383_a055acfdf643040d90f82f6a6503370a9.html#a055acfdf643040d90f82f6a6503370a9", null ],
    [ "dump", "de/dfe/a01383_a233b99aadfa1159424c90704593a4649.html#a233b99aadfa1159424c90704593a4649", null ],
    [ "size", "de/dfe/a01383_a2ddf747be11fa420e0a229639378a9fe.html#a2ddf747be11fa420e0a229639378a9fe", null ],
    [ "dims", "de/dfe/a01383.html#a713e67ad9d1e7a971c7ff820e95a202a", null ],
    [ "name", "de/dfe/a01383.html#a7771b22038e9f69aefbf06f02ca62b0a", null ],
    [ "stdname", "de/dfe/a01383.html#a6fe0d2f1985ec6a9d831b6843caf8464", null ],
    [ "tlist", "de/dfe/a01383.html#a34f6d304490b54ac47ec45b6800f585d", null ]
];