var a01919 =
[
    [ "VGridSpec", "de/d90/a01919.html#a9ed0ece1905f1206076701fb0255cb90", null ],
    [ "~VGridSpec", "de/d90/a01919.html#aba4e194fc4f889888020ecd06fc7a777", null ],
    [ "clear", "de/d90/a01919.html#af6ba9e68e9948f18a333c3c40d333cf7", null ],
    [ "set", "de/d90/a01919_ad23780c88f6e50a48811b6d3d7c3e851.html#ad23780c88f6e50a48811b6d3d7c3e851", null ],
    [ "test", "de/d90/a01919_a512770dcba4d8babe8efc35b2cff9272.html#a512770dcba4d8babe8efc35b2cff9272", null ],
    [ "code", "de/d90/a01919_a96203fa2ced5fcb969e345339bb47c9e.html#a96203fa2ced5fcb969e345339bb47c9e", null ],
    [ "levs", "de/d90/a01919.html#a295221315802d8c857f9687e049351d4", null ],
    [ "mksOffset", "de/d90/a01919.html#a5f81b17806236e727c9295f1c73df201", null ],
    [ "mksScale", "de/d90/a01919.html#a88944e7beea52715d2a4be5bb3b382db", null ],
    [ "nLevs", "de/d90/a01919.html#ad0378893ebb63716c5f007b10b6b6267", null ],
    [ "quant", "de/d90/a01919.html#ab6c27a6bb431f093ee83257f6f37b818", null ],
    [ "units", "de/d90/a01919.html#a9b7ee6dc0ab54976014ff40b6dc4c19d", null ]
];