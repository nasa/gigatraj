var a01547 =
[
    [ "Filter_Trop", "da/ded/a01547_a2eded16b62f56f0f3b64d5b6022ea77a.html#a2eded16b62f56f0f3b64d5b6022ea77a", null ],
    [ "~Filter_Trop", "da/ded/a01547_abf43014eb9093c08e2ba18b42d887eee.html#abf43014eb9093c08e2ba18b42d887eee", null ],
    [ "apply", "da/ded/a01547_a47ec5a57488a4700f4bbce695079764c.html#a47ec5a57488a4700f4bbce695079764c", null ],
    [ "apply", "da/ded/a01547_a1c7aeed5e462d4aaee0cc27503ad1cfa.html#a1c7aeed5e462d4aaee0cc27503ad1cfa", null ],
    [ "apply", "da/ded/a01547_a05ed72f2bb514f8b8cc939ffb1e129ca.html#a05ed72f2bb514f8b8cc939ffb1e129ca", null ],
    [ "apply", "da/ded/a01547_afebc98579919ee00a28df55e51b04779.html#afebc98579919ee00a28df55e51b04779", null ],
    [ "apply", "da/ded/a01547_ac0067d56ded83b0c8a0e81f3d7f23137.html#ac0067d56ded83b0c8a0e81f3d7f23137", null ],
    [ "apply", "da/ded/a01547_a7dad910de0df392dba708e59c78105ef.html#a7dad910de0df392dba708e59c78105ef", null ],
    [ "apply", "da/ded/a01547_a4feb7ec31749824f3a2785bfca02674d.html#a4feb7ec31749824f3a2785bfca02674d", null ],
    [ "direction", "da/ded/a01547_ad0557a8bc81ca43fcde1927ee86dd80f.html#ad0557a8bc81ca43fcde1927ee86dd80f", null ],
    [ "direction", "da/ded/a01547_a3b55369e5723919cdf829e64bdcd4ea6.html#a3b55369e5723919cdf829e64bdcd4ea6", null ],
    [ "field", "da/ded/a01547_a407fb6c5f7e73d7b737e02a612be21e0.html#a407fb6c5f7e73d7b737e02a612be21e0", null ],
    [ "field", "da/ded/a01547_a3f1b9c5935ce4f53d94c6f025ef17725.html#a3f1b9c5935ce4f53d94c6f025ef17725", null ],
    [ "negation", "da/ded/a01547_a6f33fca9104cd4e2bbf46f5ddd895948.html#a6f33fca9104cd4e2bbf46f5ddd895948", null ],
    [ "negation", "da/ded/a01547_ae37e7a0207f1ea2f28d5938c4a3c97a3.html#ae37e7a0207f1ea2f28d5938c4a3c97a3", null ],
    [ "quantity", "da/ded/a01547_a9c75dbc8ce4c4dbe061212b5fcb15687.html#a9c75dbc8ce4c4dbe061212b5fcb15687", null ],
    [ "quantity", "da/ded/a01547_af6c7ffa4388c2c429036e163d7313250.html#af6c7ffa4388c2c429036e163d7313250", null ],
    [ "threshold", "da/ded/a01547_afc79ef3a05443bcb75e3df5ac377c657.html#afc79ef3a05443bcb75e3df5ac377c657", null ],
    [ "threshold", "da/ded/a01547_a02e1e2bbd0dac3eaef07f16ea8e9bdf4.html#a02e1e2bbd0dac3eaef07f16ea8e9bdf4", null ]
];