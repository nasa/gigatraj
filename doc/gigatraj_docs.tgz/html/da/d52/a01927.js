var a01927 =
[
    [ "doubletrip", "d4/d25/a01939.html", "d4/d25/a01939" ],
    [ "floattrip", "d0/d43/a01935.html", "d0/d43/a01935" ],
    [ "inttrip", "d5/d31/a01931.html", "d5/d31/a01931" ],
    [ "doubleSpec", "da/d52/a01927.html#a9a94b401001c71d7a3691eb33dde5008", null ],
    [ "floatSpec", "da/d52/a01927.html#aa8b4fb7dec0b83c6d555caf846691265", null ],
    [ "intSpec", "da/d52/a01927.html#a63c951b063605986b7faf03e581f54a3", null ]
];