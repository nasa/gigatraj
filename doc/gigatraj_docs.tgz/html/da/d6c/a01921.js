var a01921 =
[
    [ "delta", "da/d6c/a01921.html#a21d5806fd9cad216f131354149a02a55", null ],
    [ "first", "da/d6c/a01921.html#a23936517d6c600fdca7b168c92b87844", null ],
    [ "last", "da/d6c/a01921.html#a6070cad57540c76ec8c7c58748e8cafa", null ],
    [ "size", "da/d6c/a01921.html#aa894fde419a36437a33fb12cfc3e48ec", null ]
];