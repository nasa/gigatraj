var a00484 =
[
    [ "HitBad", "d8/d89/a00484.html#ga1dfc3797bd66db0ec1f952f23ca26632", null ],
    [ "HitBdy", "d8/d89/a00484.html#gade68fc11db400be108f1c9f3dfa4fbc5", null ],
    [ "Inert", "d8/d89/a00484.html#ga6af05086a9e533b303ca53f98290aa6b", null ],
    [ "NonVert", "d8/d89/a00484.html#ga87f77efc4cbbee688cf5bb96cfc57dc1", null ]
];